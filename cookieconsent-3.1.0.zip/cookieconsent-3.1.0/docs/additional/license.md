# License

CookieConsent is a free and open source plugin released under the [MIT License](https://github.com/orestbida/cookieconsent/blob/master/LICENSE).