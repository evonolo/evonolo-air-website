export const title = 'CookieConsent v3 Playground';
export const description = 'A playground/configurator for CookieConsent v3';
export const repoUrl = 'https://github.com/orestbida/cookieconsent';
export const docsUrl = 'https://cookieconsent.orestbida.com';
export const playgroundUrl = 'https://playground.cookieconsent.orestbida.com';
export const stackblitzUrl = 'https://stackblitz.com/@orestbida/collections/cookieconsent-v3';